import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboardalu',
  templateUrl: './dashboardalu.component.html',
  styleUrls: ['./dashboardalu.component.css']
})
export class DashboardaluComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
