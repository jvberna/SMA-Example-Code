import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboardprof',
  templateUrl: './dashboardprof.component.html',
  styleUrls: ['./dashboardprof.component.css']
})
export class DashboardprofComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
