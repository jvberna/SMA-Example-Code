export const environment = {
  production: true,
  base_url: 'http://localhost:3000/api',
  registros_por_pagina: 10,
};
