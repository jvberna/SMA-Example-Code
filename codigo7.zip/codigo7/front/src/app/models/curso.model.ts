
export class Curso {

    constructor(
        public nombre: string,
        public nombrecorto: string,
        public activo: boolean,
        public uid?: string,
    )
    {}

}