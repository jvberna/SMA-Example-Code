
export interface loginForm {
    email: string;
    password: string;
    remember: boolean;
} 