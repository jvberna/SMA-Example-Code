// Interfaz para los datos
export interface UserSelect {
  nombre: string;
  uid: string;
}