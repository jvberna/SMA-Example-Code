import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { loginForm  } from '../interfaces/login-form.interface';
import { environment } from '../../environments/environment';
import { tap, map, catchError } from 'rxjs/operators';
import { of, Observable } from 'rxjs';
import { Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class UsuarioService {

  constructor( private http: HttpClient,
               private router: Router  ) { }

  login( formData: loginForm) {
    return this.http.post(`${environment.base_url}/login`, formData)
            .pipe(
              tap( res => {
                localStorage.setItem('token', res['token']);
              })
            );
  }

  logout() {
    localStorage.removeItem('token');
    this.router.navigateByUrl('/login');
  }

 

  validarToken(): Observable<boolean> {
    const token = localStorage.getItem('token') || '';
    if (token === '') {
      return of(false);
    }

    return this.http.get(`${environment.base_url}/login/token`, {
      headers: {
        'x-token':token
      }
      }).pipe(
        tap( res => {
          console.log('token renovado');
        }),
        map ( resp => {
          return true;
        }),
        catchError ( err => {
          localStorage.removeItem('token');
          return of(false);
        })
      )
  }

  validarNoToken(): Observable<boolean> {
    const token = localStorage.getItem('token') || '';
    if (token === '') {
      return of(true);
    }

    return this.http.get(`${environment.base_url}/login/token`, {
      headers: {
        'x-token':token
      }
      }).pipe(
        tap( res => {
          console.log('token renovado');
        }),
        map ( resp => {
          return false;
        }),
        catchError ( err => {
          localStorage.removeItem('token');
          return of(true);
        })
      )
  }  
}
